# Allagma v0.2 acceptance

All I1–I5 checks passed. See acceptance.json for exact source, checks, artifacts and limits.

The full toy manuscript is in `generic/campaigns/toy-v1/analyses/a001/paper/manuscript.md`.
Native host paths are contract fixtures; no real-model qualification is claimed.
