# Portable paper sources

Compile from the unpacked archive root with an existing TeX distribution:

```sh
python3 anc/build.py --output /path/to/new-clean-build
```

The builder verifies the source manifest and compiles in an empty temporary directory. It requires macOS sandbox-exec or Linux bubblewrap, denies network access and does not mount the reference cache. It installs nothing. For an ordinary manual TeX build, run pdflatex -no-shell-escape main.tex, bibtex main, then pdflatex twice from this root. Manual commands alone do not establish network isolation.

Use main.tex as the arXiv top-level file. References include BibTeX and the generated main.bbl. The archive contains required custom styles and final PDF/PNG/JPEG figures. No on-the-fly figure conversion, network retrieval or shell escape is needed. Build instructions, claim/result links and provenance are ancillary material in anc/. The compiled paper PDF is delivered separately. No submission has been made.

arXiv requirements were checked on 2026-10-09: https://info.arxiv.org/help/submit_tex.html and https://info.arxiv.org/help/faq/texlive.html. Supported TeX releases at that check were 2023 and 2025, with 2025 the default. The build receipt reports the actual local compiler and its scope; local success is not arXiv server validation or peer review.
